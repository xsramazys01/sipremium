import FAQPage from "../../faq-page"

export default function FAQPageRoute() {
  return <FAQPage />
}
