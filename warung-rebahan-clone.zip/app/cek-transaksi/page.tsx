import CekTransaksiPage from "../../cek-transaksi-page"

export default function CekTransaksiPageRoute() {
  return <CekTransaksiPage />
}
