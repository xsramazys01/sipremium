import PaymentMethodsPage from "../../payment-methods-page"

export default function PaymentMethodsPageRoute() {
  return <PaymentMethodsPage />
}
