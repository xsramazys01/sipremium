import GaransiPage from "../../garansi-page"

export default function GaransiPageRoute() {
  return <GaransiPage />
}
