import TestimoniPage from "../../testimoni-page"

export default function TestimoniPageRoute() {
  return <TestimoniPage />
}
