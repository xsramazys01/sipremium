import WarungRebahanClone from "../warung-rebahan"

export default function Page() {
  return <WarungRebahanClone />
}
